import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Double_Zoog extends PApplet {

public void setup() {
  // Set the size of the window
  size(500,500);
}

public void draw() {
  // Draw a white background
  background(0,255,255);
  zoog(mouseX-70,mouseY, 0xff11B2EA);
  zoog(mouseX+70,mouseY, color(125,50,70));
  zoog(mouseX,mouseY, 255);  
}

public void zoog(int xpos, int ypos, int c1) {
  // Set CENTER mode
  ellipseMode(CENTER);
  rectMode(CENTER);
  
  // Draw Zoog's body
  stroke(0);
  fill(c1);
  rect(xpos,ypos,20,100);
  
  // Draw Zoog's head
  stroke(0);
  fill(255);
  ellipse(xpos,ypos-70,60,60);
  
  // Draw Zoog's eyes
  fill(0,155,0);
  ellipse(xpos-19,ypos-70,16,32);
  ellipse(xpos+19,ypos-70,16,32);
  
  // Draw Zoog's legs
  stroke(0);
  line(xpos-10,ypos+50,xpos-20,ypos+75);
  line(xpos+10,ypos+50,xpos+20,ypos+75);
  
  // Draw Zoog's arm
  stroke(0);
  line(xpos-10,ypos-10,xpos-20,ypos-20);
  line(xpos+10,ypos-10,xpos+20,ypos-20);
  
  // Draw Zoog's mouth
  fill(0);
  ellipse(xpos,ypos-50,10,10);
  
  // Draw Zoog's tie
  fill(255,0,0);
  quad(xpos,ypos+15,xpos-5,ypos-15,xpos,ypos-30,xpos+5,ypos-15);
  
  // Draw Zoog's shoes
  fill(255,0,0);
  ellipse(xpos-20,ypos+75,12,8);
  ellipse(xpos+20,ypos+75,12,8);
}
  
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Double_Zoog" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
