public class Answers {

  private String answers[];
  
  public Answers(String...a) {
    this.answers = a;
  }
  
  public String toString(int e) {
    return answers [e];
  }
}