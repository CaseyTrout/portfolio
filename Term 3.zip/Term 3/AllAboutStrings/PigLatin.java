import java.io.*;
import java.util.Scanner;

class PigLatin {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    String Str1, Str2;
    System.out.print("Enter a word to translate to PigLatin: ");
    Str1 = keyboard.nextLine();
    Str2 = Str1.substring(0,1);
    System.out.println("Your new word is: " + Str1.substring(1) + Str2 + "ay");
  }
}