import java.util.Scanner;

public class PigLatinName {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    System.out.println("What is your first name?");
    String firstName = keyboard.nextLine();
    firstName = firstName.toLowerCase();
    String firstLetter, nextLetters;
    firstLetter = firstName.substring(0,1);
    nextLetters = firstName.substring(1);
    System.out.println(nextLetters + firstLetter + "a");
    }
  }