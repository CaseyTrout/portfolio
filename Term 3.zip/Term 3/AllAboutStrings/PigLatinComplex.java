import java.io.*;
import java.util.Scanner;

class PigLatinComplex {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Enter a word to translate to Pig Latin: ");
    System.out.println(makePig(keyboard.next()));
  }
  
  public static String makePig(String word) {
    word = word.toLowerCase();
    int i = 0;
    String pigWord, result;
    if(word.charAt(0) == 'a' || word.charAt(0) == 'e' || word.charAt(0) == 'i' || word.charAt(0) == 'o' ||
      word.charAt(0) == 'u') {
        result = word + "yay";
      } else {
          String letter = word.substring(0,1);
          word = word.substring(1);
          result = word + letter + "ay";
      } return result;
    }
}

