public class StringPractice {
  public static void main(String[] args) {
    String fullName = "Casey Trout";
    //fullName = fullName.toUpperCase();
    //fullName = fullName.toLowerCase();
    int age = 17;
    System.out.println(fullName + " is " + age + ".");
    int len = fullName.length();
    System.out.println("String length is: " + len);
    String firstName, lastName;
    firstName = fullName.substring(0,5);
    lastName = fullName.substring(6,11);
    System.out.println(firstName + "\n" + lastName);
  }
}