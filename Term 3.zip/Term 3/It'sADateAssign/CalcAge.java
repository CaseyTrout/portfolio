import java.util.Scanner;
import java.util.Calendar;

public class CalcAge {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Birth Year (YYYY)");
    int year = keyboard.nextInt();
    System.out.println("Birth Month (MM)");
    int month = keyboard.nextInt();
    System.out.println("Birth Day (DD)");
    int day = keyboard.nextInt();
    Calendar cal = Calendar.getInstance();
    int yearAge = (cal.get(Calendar.YEAR)) - year;
    int monthAge = (cal.get(Calendar.MONTH)) - month + 1;
    int dayAge = (cal.get(Calendar.DATE)) - day;
    if(monthAge < 0) {
      yearAge --;
      monthAge += 12;
    }
    if(dayAge < 0){
      dayAge = dayAge * -1;
    }
    if(dayAge == 1 && monthAge != 1 && yearAge != 1) {
      System.out.println(yearAge + " years, " + monthAge + " months and " + dayAge + " day old.");
    } else if(dayAge != 1 && monthAge == 1 && yearAge != 1) {
      System.out.println(yearAge + " years, " + monthAge + " month and " + dayAge + " days old.");
    } else if(dayAge != 1 && monthAge != 1 && yearAge == 1) {
      System.out.println(yearAge + " year, " + monthAge + " months and " + dayAge + " days old.");
    } else if(dayAge == 1 && monthAge == 1 && yearAge != 1) {
      System.out.println(yearAge + " years, " + monthAge + " month and " + dayAge + " day old.");
    } else if(dayAge == 1 && monthAge != 1 && yearAge == 1) {
      System.out.println(yearAge + " year, " + monthAge + " months and " + dayAge + " day old.");
    } else if(dayAge != 1 && monthAge == 1 && yearAge == 1) {
      System.out.println(yearAge + " year, " + monthAge + " month and " + dayAge + " days old.");
    } else if(dayAge == 1 && monthAge == 1 && yearAge == 1) {
      System.out.println(yearAge + " year, " + monthAge + " month and " + dayAge + " day old.");
    } else {
      System.out.println(yearAge + " years, " + monthAge + " months and " + dayAge + " days old.");
    }
    if(monthAge == 0 && dayAge == 0){
      System.out.println("Happy Birthday!");
    }
  }
}