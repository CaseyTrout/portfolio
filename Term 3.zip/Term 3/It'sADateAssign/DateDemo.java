import java.util.*;
import java.text.*;

public class DateDemo {
  public static void main(String args[]) {
    //Instantiate a Date object
    Date date = new Date();
    SimpleDateFormat ft =
    new SimpleDateFormat ("hh:mm:ss a zzz");
    
    //Display time and date using toString()
    System.out.println(ft.format(date));
  }
}