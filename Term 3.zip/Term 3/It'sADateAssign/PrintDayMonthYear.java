import java.util.*;
import java.text.*;

public class PrintDayMonthYear {
  public static void main(String args[]) {
    //Instantiate a Date object
    Date date = new Date();
    SimpleDateFormat ft =
    new SimpleDateFormat ("DD MMMM Y");
    
    //Display time and date using toString()
    System.out.println(ft.format(date));
  }
}