import java.util.*;
import java.text.*;

public class PrintDateToString {
  public static void main(String args[]) {
    //Instantiate a Date object
    Date date = new Date();
    SimpleDateFormat ft =
    new SimpleDateFormat ("EEEE, MMMM dd, y 'at' hh:mm:ss a zzz");
    
    //Display time and date using toString()
    System.out.println(ft.format(date));
  }
}