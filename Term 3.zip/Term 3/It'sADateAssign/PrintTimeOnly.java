import java.util.*;
import java.text.*;

public class PrintTimeOnly {
  public static void main(String args[]) {
    //Instantiate a Date object
    Date date = new Date();
    SimpleDateFormat ft =
    new SimpleDateFormat ("dd.MM.yyyy");
    
    //Display time and date using toString()
    System.out.println(ft.format(date));
  }
}