// Child or Sub Class
public class Flower extends Plant {
  // Member variables
  private String petalColor = "";
  private int petals = 0;

  // Default constructor
  public Flower() {}
  
  // Set method
  public void setPetalColor(String tempColor) {
    petalColor = tempColor;
  }
  
  public void setPetals(int p) {
    petals = p;
  }
  
  // Get method
  public String getPetalColor() {
    return petalColor;
  }
  
  public int getPetals() {
    return petals;
  }
  
  public int calcLeavesAndPetals() {
    int total = getLeafCount() + petals;
    return total;
  }
}