// Child or Sub Class
public class Van extends Vehicle {
  // Member variables
  private int doorCount = 6;
  private int length = 0;
  private int width = 0;
  private int height = 0;
  // private boolean handleBars = true;
  
  // Default constructor
  public Van() {}
  
  // Add constructor to assign new values to length, width, and height when instantiated
  public Van(int l, int w, int h) {
    // Set the new values
  }
  
  // Set method
  public void setDoorCount(int d) {
    doorCount = d;
  }
  
  // Get method
  public int getDoorCount() {
    return doorCount;
  }
  
  // To do: Add method to calculate something
  // Ideas: fuel efficiency, distance per tank of gas, vehicle mass, etc.
}