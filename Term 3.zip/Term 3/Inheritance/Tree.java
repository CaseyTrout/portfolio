// Child or Sub Class
public class Tree extends Plant {
  // Member variables
  private String leafColor = "";
  private int branches = 0;

  // Default constructor
  public Tree() {}
  
  // Set method
  public void setLeafColor(String tempColor) {
    leafColor = tempColor;
  }
  
  public void setBranches(int b) {
    branches = b;
  }
  
  // Get method
  public String getLeafColor() {
    return leafColor;
  }
  
  public int getBranches() {
    return branches;
  }
  
  public int calcLeavesOnBranch() {
    int total = getLeafCount()/branches;
    return total;
  }
}