// Base Class/Superclass
public class Plant {
  private int leafCount = 0;
  private int height = 0;
  private String type = "";
  
  // Set method
  public void setLeafCount(int lc) {
    leafCount = lc;
  }
  
  public void setHeight(int h) {
    height = h;
  }
  
  public void setType(String t) {
    type = t;
  } 
  
  // Get method
  public int getLeafCount() {
    return leafCount;
  }
  
  public int getHeight() {
    return height;
  }
  
  public String getType() {
    return type;
  }
}