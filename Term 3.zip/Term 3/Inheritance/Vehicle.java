// Base Class/Superclass
public class Vehicle {
  private int topSpeed = 50;
  private int wheels = 4;
  
  // Set method
  public void setTopSpeed(int s) {
    topSpeed = s;
  }
  
  public void setWheels(int w) {
    wheels = w;
  }
  
  // Get method
  public int getTopSpeed() {
    return topSpeed;
  }
  
  public int getWheel() {
    return wheels;
  }
}