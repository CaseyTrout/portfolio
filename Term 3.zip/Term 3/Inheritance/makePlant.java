import java.util.Scanner;

// Child or Sub Class
class makePlant {
  public static void main(String[] args) {
    // Instantiate Scanner
    Scanner keyboard = new Scanner(System.in);
    // Instantiate
    Tree myTree = new Tree();
    Flower myFlower = new Flower();
    String plant;
    
    // Ask the user which object they want to make
    System.out.println("Would you like to make a tree or flower?");
    plant = keyboard.nextLine();
    
    // Modify values in the object by calling your get and set methods
    if(plant.equals("tree")) {
      System.out.println("\n" + "What type of tree would you like?");
      myTree.setType(keyboard.next());
      
      System.out.println("Ok, your tree is now a " + myTree.getType() + "\n");
      
      System.out.println("How tall would you like your tree to be (in feet)?");
      // Program breaks if user enters a string following the integer
      myTree.setHeight(keyboard.nextInt());
      
      System.out.println("Ok, your tree is now " + myTree.getHeight() + " feet tall" + "\n");
      
      System.out.println("How many branches would you like?");
      myTree.setBranches(keyboard.nextInt());
      
      System.out.println("Ok, your tree now has " + myTree.getBranches() + " branches" + "\n");
      
      System.out.println("How many leaves would you like?");
      myTree.setLeafCount(keyboard.nextInt());
      
      System.out.println("Ok, your tree now has " + myTree.getLeafCount() + " leaves" + "\n");
      
      System.out.println("What color leaves would you like?");
      myTree.setLeafColor(keyboard.next());
      
      System.out.println("Ok, your leaves are now " + myTree.getLeafColor() + "\n");
      
      System.out.println("Here is a summary of your tree: " + "\n" + "Type: " + myTree.getType() + "\n" +
                         "Height: " + myTree.getHeight() + " feet" + "\n" + "Number of branches: " + myTree.getBranches() + "\n" +
                         "Number of Leaves: " + myTree.getLeafCount() + "\n" + "Leaf Color: " + myTree.getLeafColor() + "\n" 
                         + "Total number of leaves on each branch is: " + myTree.calcLeavesOnBranch());
    } else if(plant.equals("flower")) {
      System.out.println("\n" + "What type of flower would you like?");
      myFlower.setType(keyboard.next());
      
      System.out.println("Ok, your flower is now a " + myFlower.getType() + "\n");
      
      System.out.println("How tall would you like your flower to be (in inches)?");
      // Program breaks if user enters a string following the integer
      myFlower.setHeight(keyboard.nextInt());
      
      System.out.println("Ok, your flower is now " + myFlower.getHeight() + " inches tall" + "\n");
      
      System.out.println("How many petals would you like?");
      myFlower.setPetals(keyboard.nextInt());
      
      System.out.println("Ok, your flower now has " + myFlower.getPetals() + " petals" + "\n");
      
      System.out.println("What color petals would you like?");
      myFlower.setPetalColor(keyboard.next());
      
      System.out.println("Ok, your petals are now " + myFlower.getPetalColor() + "\n");
      
      System.out.println("How many leaves would you like?");
      myFlower.setLeafCount(keyboard.nextInt());
      
      System.out.println("Ok, your flower now has " + myFlower.getLeafCount() + " leaves" + "\n");
      
      System.out.println("Here is a summary of your flower: " + "\n" + "Type: " + myFlower.getType() + "\n" +
                         "Height: " + myFlower.getHeight() + " inches" + "\n" + "Number of petals: " + myFlower.getPetals()
                         + "\n" + "Petal Color: " + myFlower.getPetalColor() + "\n" + "Number of Leaves: " + myFlower.getLeafCount()
                         + "\n" + "Total number of leaves and petals is: " + myFlower.calcLeavesAndPetals());
    } else {
      System.out.println("Please recompile and enter 'tree' or 'flower'");
    }
  }
}