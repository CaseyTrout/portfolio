import java.util.Scanner;

// Child or Sub Class
class makeCars {
  public static void main(String[] args) {
    // Instantiate Scanner
    Scanner keyboard = new Scanner(System.in);
    // Instantiate a van: try it with a modified constructor
    Van myVan = new Van();
    
    // See what is in the default instantiation
    System.out.println("The current top speed of your new van is: " + myVan.getTopSpeed());
    System.out.println("The number of doors on your new van is: " + myVan.getDoorCount());
    System.out.println("The number of wheels on your new van is: " + myVan.getWheel());
    
    // Modify values in the myVan object by calling your get and set methods
    System.out.println("Lets modify it with a new engine, how fast would you like it to go? ");
    myVan.setTopSpeed(keyboard.nextInt());
    
    System.out.println("Ok, it now goes " + myVan.getTopSpeed() + " miles per hour!");
    
    System.out.println("How many doors would you like in your new van?: ");
    myVan.setDoorCount(keyboard.nextInt());
    
    System.out.println("Ok, your van now has " + myVan.getDoorCount() + " doors.");
  }
}