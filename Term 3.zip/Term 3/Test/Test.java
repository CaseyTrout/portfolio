// Question 1
int num1 = 2955888889;

// Question 2
boolean isComplete = false;

// Question 3
if (isComplete == true) {
  num1++;
} else {
  num1--;
}

// Question 4
if (num1 <= 10) {
  num1*num1;
} else {
  isComplete = true;
}

// Question 5
public int getNum1() {
  return num1;
}

// Question 6
public int calcAge(int currentYear, int birthYear) {
  result = currentYear - birthYear;
  return result;
}

// Question 7
public class Battleship extends Vessel {
  int turretCount;
  boolean hasWoodDeck;
  
  public void setHasWoodDeck(boolean d) {
    hasWoodDeck = d;
  }
  
  public int getTurretCount() {
    return turretCount;
  }
}

// Question 8
public Battleship(boolean w, int t) {}

// Question 9
Battleship = new battleS1();

// Question 10
setHasWoodDeck(true);