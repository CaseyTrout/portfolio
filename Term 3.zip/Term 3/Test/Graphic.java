//Sonia Liu
import java.applet.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import javax.swing.*;

public class Graphic extends Applet {
  public void init () {
    setBackground(Color.blue);
  }
  
  public void paint (Graphics a) {

    a.setColor(Color.black);
    a.drawRect(10,30,500,740);
    a.drawRect(10,140,500,50);
    a.drawRect(10,30,500,100);
    a.drawRect(10,190,500,100);
    a.drawRect(10,390,500,100);
    a.drawRect(10,590,500,100);
    a.drawRect(110,140,100,550);
    a.drawRect(310,140,100,550);
    
    // Casey Trout
    
    // Add text for title
    Font titleFont = new Font("Goudy Stout", Font.PLAIN, 20);
    a.setFont(titleFont);
    a.drawString("Welcome to", 20, 60);
    a.drawString("European History", 40, 85);
    a.drawString("Jeopardy!", 60, 110);
    
    // Add text for categories
    Font catFont = new Font("Mongolian Baiti", Font.BOLD, 12);
    a.setFont(catFont);
    a.drawString("Renaissance", 20, 170);
    a.drawString("New Monarchies", 120, 170);
    a.drawString("Absolutism", 220, 170);
    a.drawString("Enlightenment", 320, 170);
    a.drawString("French Revolution", 420, 170);
    
    // Add text for instructions
    Font insFont = new Font("Times New Roman", Font.PLAIN, 30);
    a.setFont(insFont);
    a.drawString("Select a category to begin.", 20, 725);
  }
}
