public class Box {
  private float length;
  private float width;
  private float height;
  private float volume;
  private float sa;
  public Box() {}
  
  public float calcVolume(float tempLength, float tempWidth, float tempHeight) {
    length = tempLength;
    width = tempWidth;
    height = tempHeight;
    volume = length*width*height;
    return volume;
  }
  
  public float calcSA(float tempLength, float tempWidth, float tempHeight) {
    length = tempLength;
    width = tempWidth;
    height = tempHeight;
    sa = 2*(width*length + height*length + height*width);
    return sa;
  }
}
