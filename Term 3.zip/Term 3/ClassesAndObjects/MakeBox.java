import java.util.Scanner;

public class MakeBox {
  public static void main(String args[]) {
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Enter the dimensions of your box below to calculate volume and surface area in meters. Do not include units.");
    System.out.print("Enter length: ");
    float inputL = keyboard.nextInt();
    System.out.print("Enter width: ");
    float inputW = keyboard.nextInt();
    System.out.print("Enter height: ");
    float inputH = keyboard.nextInt();
    
    Box box1 = new Box();
    System.out.println("Box volume is: " + box1.calcVolume(inputL, inputW, inputH) + " meters cubed");
    System.out.println("Box surface area is: " + box1.calcSA(inputL, inputW, inputH) + " meters squared");
  }
}