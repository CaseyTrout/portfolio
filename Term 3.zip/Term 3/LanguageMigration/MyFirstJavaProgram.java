public class MyFirstJavaProgram {

   /* This is my first java program.  
    * This will print 'Hello World' as the output
    */

    public static void main(String []args) {
      int num1 = 10;
      double num2 = 3.14;
      String firstName = "Casey";
      long bigNum;
      int a, b, c, d;
      a = random();
      System.out.println("Hello World"); // prints Hello World
    }
} 