import java.util.Scanner;
public class arrayDice {
  public static void main(String[] args) {
    System.out.println("This program will simulate dice rolls. Enter the number of sides on the dice and then the number of dice being rolled and the program will print the results." + "\n");
    Scanner k = new Scanner(System.in);
    System.out.print("Maximum Dice Number: ");
    int maxDice = k.nextInt();
    System.out.print("Quantity of Dice: ");
    int quantityDice = k.nextInt();
    int[] dice = new int[maxDice];
    for(int i=0; i<dice.length; i++) {
      dice[i] = i+1;
    }
    for(int i=1; i<=quantityDice; i++) {
      System.out.print("Dice #" + i + " is: " + dice[(int)(Math.random()*dice.length)] + "\n");
    }
  }
}