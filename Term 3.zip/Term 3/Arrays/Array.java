import java.util.Random;

public class Array {
  public static void main(String[] args) {
    //int[] nums = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    //for(int i=0; i<nums.length; i++) {
      //if(i==0) {
        //nums[i] = 5;
      
      //System.out.println(nums[i]);
      //System.out.println(nums[1]);
    
    int[] myList = {100};
    for(int a=0; a<=99; a++) {
      Random rand = new Random();
      myList[a] = rand.nextInt();
      System.out.println(myList[a]);
    }
  }
}