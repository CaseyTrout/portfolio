import java.io.*;
import java.util.Scanner;
import java.io.BufferedWriter;

public class IOPractice2 {
  public static void main(String args[]) throws IOException {
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Type here: ");
    String text = keyboard.nextLine();
    File outputtext = new File("output.txt");
    try {
      BufferedWriter output = new BufferedWriter(new FileWriter(outputtext));
      output.write(text);
      output.close();
    } catch(IOException e) {
      e.printStackTrace();
    }
  }
}