import java.io.*;

public class IOPractice {
  public static void main(String args[]) throws IOException {
    FileInputStream in = null;
    InputStreamReader input = null;
    try {
      input = new InputStreamReader(System.in);
      System.out.print("Type here: ");
      char c;
      do {
        c = (char) input.read();
        System.out.print(c);
      } while (c != 'q');
    } finally {
      if (input != null) {
        input.close();
      }
    }
  }
}