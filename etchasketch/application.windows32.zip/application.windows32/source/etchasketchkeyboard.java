import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class etchasketchkeyboard extends PApplet {

// Global Variable
int x, y;

public void setup() {
  size(400,400);
  frameRate(10);
  // Set start coordinates
  x=0;
  y=0;
}
public void draw() {}

public void keyPressed() {
  if(key == CODED) {
    if(keyCode == RIGHT) {
      if(x>=width) {
        x=width;
      }
      moveRight(1);
    } else if (keyCode == DOWN) {
      if(y>=height) {
        y=height;
      }
      moveDown(1);
    } else if (keyCode == UP) {
      if(y>=height) {
        y=height;
      }
      moveUp(1);
    } else if (keyCode == LEFT) {
      if(x>=width) {
        x=width;
      }
      moveLeft(1);
    } 
  }
}

public void mouseClicked() {
  saveFrame("line-######.png");
}

//Method to draw right line
public void moveRight(int rep) {
  for(int i=0;i<rep;i++) {
    point(x+i,y);
  }
  x=x+(rep);
}

//Method to draw left line
public void moveLeft(int rep) {
  for(int i=0;i<rep;i++) {
    point(x-i,y);
  }
  x=x-(rep);
}

//Method to draw line down
public void moveDown(int rep) {
  for(int i=0;i<rep;i++) {
    point(x,y+i);
  }
  y=y+(rep);
}

//Method to draw line up
public void moveUp(int rep) {
  for(int i=0;i<rep;i++) {
    point(x,y-i);
  }
  y=y-(rep);
}

//Method to draw right upwards diagonal
public void moveRU(int rep) {
  for(int i=0;i<rep;i++) {
    point(x+i,y-i);
  }
  x=x+(rep);
  y=y-(rep);
}

//Method to draw right downwards diagonal
public void moveRD(int rep) {
  for(int i=0;i<rep;i++) {
    point(x+i,y+i);
  }
  x=x+(rep);
  y=y+(rep);
}

//Method to draw left upwards diagonal
public void moveLU(int rep) {
  for(int i=0;i<rep;i++) {
    point(x-i,y-i);
  }
  x=x-(rep);
  y=y-(rep);
}

//Method to draw left downwards diagonal
public void moveLD(int rep) {
  for(int i=0;i<rep;i++) {
    point(x+i,y+i);
  }
  x=x+(rep);
  y=y+(rep);
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "etchasketchkeyboard" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
